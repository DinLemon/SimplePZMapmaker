function SpawnRegions()
 return { { name = "SimplePZMap_e9750d5db971", file = "media/maps/SimplePZMap_e9750d5db971/spawnpoints.lua" } }
end
