function SpawnRegions()
 return { { name = "SimplePZMap_6a74a4cc9b5a", file = "media/maps/SimplePZMap_6a74a4cc9b5a/spawnpoints.lua" } }
end
