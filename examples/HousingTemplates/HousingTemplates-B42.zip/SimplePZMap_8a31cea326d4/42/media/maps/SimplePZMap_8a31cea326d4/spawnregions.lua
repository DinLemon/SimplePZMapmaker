function SpawnRegions()
 return { { name = "SimplePZMap_8a31cea326d4", file = "media/maps/SimplePZMap_8a31cea326d4/spawnpoints.lua" } }
end
