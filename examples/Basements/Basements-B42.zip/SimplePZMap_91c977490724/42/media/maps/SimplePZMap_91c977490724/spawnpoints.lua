function SpawnPoints()
    local points = {
        { posX = 25728, posY = 25728, posZ = 0 }
    }
    return { unemployed = points }
end
