function SpawnPoints()
    local points = {
        { posX = 25604, posY = 25604, posZ = 0 }
    }
    return { unemployed = points }
end
