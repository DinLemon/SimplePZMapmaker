function SpawnPoints()
    local points = {
        { posX = 26624, posY = 26624, posZ = 0 }
    }
    return { unemployed = points }
end
