function SpawnRegions()
 return { { name = "SimplePZWorld_1051541ba317", file = "media/maps/SimplePZWorld_1051541ba317/spawnpoints.lua" } }
end
