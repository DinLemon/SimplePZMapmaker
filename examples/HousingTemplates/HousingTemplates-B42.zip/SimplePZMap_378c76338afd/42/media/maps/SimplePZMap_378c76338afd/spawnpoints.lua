function SpawnPoints()
    local points = {
        { posX = 25612, posY = 25612, posZ = 0 }
    }
    return { unemployed = points }
end
