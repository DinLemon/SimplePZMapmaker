-- Original SimplePZMapmaker glue. Registered models remain in their owning mods.
local placements = {
 ["25646:25656:-1"] = {
 { id="0f000006000000000000000000000002", type="SPZMC17DCEDA8523.PropBF08714845AD00EB", x=0.5, y=0.5, z=0, rotation=0, scale=0.5 },
 },
}
local function load(square)
 if isClient() then return end
 local list=placements[square:getX()..':'..square:getY()..':'..square:getZ()]
 if not list then return end
 local data=square:getModData()
 data.SPZMC17DCEDA8523=data.SPZMC17DCEDA8523 or {}
 local done=data.SPZMC17DCEDA8523
 for _,p in ipairs(list) do
  if not done[p.id] then
   local item=instanceItem(p.type)
   if item then
    item:setWorldScale(p.scale)
    item:setWorldZRotation(p.rotation)
    local placed=square:AddWorldInventoryItem(item,p.x,p.y,p.z,false)
    if placed and placed:getWorldItem() then
     placed:getWorldItem():setIgnoreRemoveSandbox(true)
     placed:getWorldItem():transmitCompleteItemToClients()
     done[p.id]=true
    end
   end
  end
 end
end
Events.LoadGridsquare.Add(load)
