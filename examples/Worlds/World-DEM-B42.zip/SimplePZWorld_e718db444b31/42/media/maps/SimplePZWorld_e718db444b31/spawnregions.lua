function SpawnRegions()
 return { { name = "SimplePZWorld_e718db444b31", file = "media/maps/SimplePZWorld_e718db444b31/spawnpoints.lua" } }
end
