function SpawnPoints()
 local points = {
 { posX = 33536, posY = 33536, posZ = 0 }
 }
 return { unemployed = points }
end
