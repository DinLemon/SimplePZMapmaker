function SpawnRegions()
 return { { name = "SimplePZMap_144fe338ba7b", file = "media/maps/SimplePZMap_144fe338ba7b/spawnpoints.lua" } }
end
