function SpawnRegions()
 return { { name = "SimplePZMap_378c76338afd", file = "media/maps/SimplePZMap_378c76338afd/spawnpoints.lua" } }
end
