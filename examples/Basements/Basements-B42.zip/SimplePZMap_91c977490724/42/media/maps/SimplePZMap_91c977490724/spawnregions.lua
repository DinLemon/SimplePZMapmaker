function SpawnRegions()
 return { { name = "SimplePZMap_91c977490724", file = "media/maps/SimplePZMap_91c977490724/spawnpoints.lua" } }
end
