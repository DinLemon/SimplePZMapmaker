-- Original SimplePZMapmaker glue. Registered models remain in their owning mods.
local placements = {
 ["25700:25660:0"] = {
 { id="b5a4c0266ab84b4e9446a4d1279aea97", profile="container", type="SPZM4211B3CC1643.Prop381C6224077B95CF", spriteModel="SPZM4211B3CC1643.SceneAEC30F60F31D21D6825299C9", blocking=true, destructible=true, health=500, capacity=75, x=0.5, y=0.5, z=0, rotation=0, scale=2 },
 },
}
local function load(square)
 if isClient() then return end
 local list=placements[square:getX()..':'..square:getY()..':'..square:getZ()]
 if not list then return end
 local data=square:getModData()
 data.SPZM4211B3CC1643=data.SPZM4211B3CC1643 or {}
 local done=data.SPZM4211B3CC1643
 for _,p in ipairs(list) do
  if not done[p.id] then
   if p.profile=='pickup' then
    local item=instanceItem(p.type)
    if item then
     item:setWorldScale(p.scale)
     item:setWorldZRotation(p.rotation)
     local placed=square:AddWorldInventoryItem(item,p.x,p.y,p.z,false)
     if placed and placed:getWorldItem() then
      placed:getWorldItem():setIgnoreRemoveSandbox(true)
      placed:getWorldItem():transmitCompleteItemToClients()
      done[p.id]=true
     end
    end
   else
    local object=IsoThumpable.new(getCell(),square,'invisible_01_0',false,{})
    object:setSpriteModelName(p.spriteModel)
    object:setName('Static scenery')
    object:setCanPassThrough(not p.blocking)
    object:setBlockAllTheSquare(p.blocking)
    object:setIsThumpable(p.destructible)
    object:setIsDismantable(false)
    object:setMaxHealth(p.health)
    object:setHealth(p.health)
    object:getModData().SPZMPlacementId=p.id
    if p.profile=='container' then
     object:setIsContainer(true)
     object:getContainer():setCapacity(p.capacity)
     object:getContainer():setExplored(true)
    end
    square:AddSpecialObject(object)
    square:RecalcAllWithNeighbours(true)
    object:transmitCompleteItemToClients()
    done[p.id]=true
   end
  end
 end
end
Events.LoadGridsquare.Add(load)
