function SpawnPoints()
 local points = {
 { posX = 25680, posY = 25680, posZ = 0 },
 { posX = 25936, posY = 25680, posZ = 0 }
 }
 return { unemployed = points }
end
