function SpawnRegions()
 return { { name = "SimplePZMap_708a15b5e5bd", file = "media/maps/SimplePZMap_708a15b5e5bd/spawnpoints.lua" } }
end
