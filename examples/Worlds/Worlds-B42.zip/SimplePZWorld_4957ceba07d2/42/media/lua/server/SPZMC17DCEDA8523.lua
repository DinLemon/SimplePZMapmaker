-- Original SimplePZMapmaker glue. Registered models remain in their owning mods.
local placements = {
 ["25646:25656:-1"] = {
 { id="0f000006000000000000000000000002", profile="pickup", type="SPZMC17DCEDA8523.PropBF08714845AD00EB", spriteModel="SPZMC17DCEDA8523.Scene902C231FCB612EE397BD2347", blocking=false, destructible=false, health=500, capacity=50, x=0.5, y=0.5, z=0, rotation=0, scale=0.5 },
 },
}
local function load(square)
 if isClient() then return end
 local list=placements[square:getX()..':'..square:getY()..':'..square:getZ()]
 if not list then return end
 local data=square:getModData()
 data.SPZMC17DCEDA8523=data.SPZMC17DCEDA8523 or {}
 local done=data.SPZMC17DCEDA8523
 for _,p in ipairs(list) do
  if not done[p.id] then
   if p.profile=='pickup' then
    local item=instanceItem(p.type)
    if item then
     item:setWorldScale(p.scale)
     item:setWorldZRotation(p.rotation)
     local placed=square:AddWorldInventoryItem(item,p.x,p.y,p.z,false)
     if placed and placed:getWorldItem() then
      placed:getWorldItem():setIgnoreRemoveSandbox(true)
      placed:getWorldItem():transmitCompleteItemToClients()
      done[p.id]=true
     end
    end
   else
    local object=IsoThumpable.new(getCell(),square,'invisible_01_0',false,{})
    object:setSpriteModelName(p.spriteModel)
    object:setName('Static scenery')
    object:setCanPassThrough(not p.blocking)
    object:setBlockAllTheSquare(p.blocking)
    object:setIsThumpable(p.destructible)
    object:setIsDismantable(false)
    object:setMaxHealth(p.health)
    object:setHealth(p.health)
    object:getModData().SPZMPlacementId=p.id
    if p.profile=='container' then
     object:setIsContainer(true)
     object:getContainer():setCapacity(p.capacity)
     object:getContainer():setExplored(true)
    end
    square:AddSpecialObject(object)
    square:RecalcAllWithNeighbours(true)
    object:transmitCompleteItemToClients()
    done[p.id]=true
   end
  end
 end
end
Events.LoadGridsquare.Add(load)
