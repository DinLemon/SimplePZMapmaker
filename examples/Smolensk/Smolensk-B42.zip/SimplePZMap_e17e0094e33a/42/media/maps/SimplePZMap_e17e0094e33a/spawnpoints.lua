function SpawnPoints()
    local points = {
        { posX = 26112, posY = 26112, posZ = 0 }
    }
    return { unemployed = points }
end
