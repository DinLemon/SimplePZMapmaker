function SpawnRegions()
 return { { name = "SimplePZWorld_20fb35245612", file = "media/maps/SimplePZWorld_20fb35245612/spawnpoints.lua" } }
end
