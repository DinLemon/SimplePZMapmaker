function SpawnRegions()
 return { { name = "SimplePZMap_2e766d42c917", file = "media/maps/SimplePZMap_2e766d42c917/spawnpoints.lua" } }
end
