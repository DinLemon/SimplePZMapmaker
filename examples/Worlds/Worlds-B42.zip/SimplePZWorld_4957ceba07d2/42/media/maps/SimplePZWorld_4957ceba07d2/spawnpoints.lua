function SpawnPoints()
 local points = {
 { posX = 25728, posY = 25728, posZ = 0 },
 { posX = 25620, posY = 26132, posZ = 0 },
 { posX = 25984, posY = 25728, posZ = 0 },
 { posX = 26240, posY = 25728, posZ = 0 },
 { posX = 26496, posY = 25728, posZ = 0 },
 { posX = 26752, posY = 25728, posZ = 0 },
 { posX = 27008, posY = 25728, posZ = 0 },
 { posX = 27264, posY = 25728, posZ = 0 },
 { posX = 27520, posY = 25728, posZ = 0 },
 { posX = 27776, posY = 25728, posZ = 0 },
 { posX = 28032, posY = 25728, posZ = 0 },
 { posX = 28288, posY = 25728, posZ = 0 },
 { posX = 28544, posY = 25728, posZ = 0 }
 }
 return { unemployed = points }
end
