function SpawnRegions()
 return { { name = "SimplePZMap_9e199fbe7daa", file = "media/maps/SimplePZMap_9e199fbe7daa/spawnpoints.lua" } }
end
