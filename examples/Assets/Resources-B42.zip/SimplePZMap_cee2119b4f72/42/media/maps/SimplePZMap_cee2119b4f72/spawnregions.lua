function SpawnRegions()
 return { { name = "SimplePZMap_cee2119b4f72", file = "media/maps/SimplePZMap_cee2119b4f72/spawnpoints.lua" } }
end
