function SpawnRegions()
 return { { name = "SimplePZMap_e17e0094e33a", file = "media/maps/SimplePZMap_e17e0094e33a/spawnpoints.lua" } }
end
