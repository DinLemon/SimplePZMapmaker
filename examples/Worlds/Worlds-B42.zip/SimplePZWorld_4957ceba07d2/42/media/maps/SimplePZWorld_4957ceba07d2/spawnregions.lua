function SpawnRegions()
 return { { name = "SimplePZWorld_4957ceba07d2", file = "media/maps/SimplePZWorld_4957ceba07d2/spawnpoints.lua" } }
end
