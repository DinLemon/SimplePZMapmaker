function SpawnRegions()
 return { { name = "SimplePZWorld_2e27955c3609", file = "media/maps/SimplePZWorld_2e27955c3609/spawnpoints.lua" } }
end
