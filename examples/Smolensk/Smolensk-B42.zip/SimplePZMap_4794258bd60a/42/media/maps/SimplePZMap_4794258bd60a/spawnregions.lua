function SpawnRegions()
 return { { name = "SimplePZMap_4794258bd60a", file = "media/maps/SimplePZMap_4794258bd60a/spawnpoints.lua" } }
end
